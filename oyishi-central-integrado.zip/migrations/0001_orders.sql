CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, source_call_id TEXT UNIQUE,
 customer_name TEXT NOT NULL, customer_phone TEXT, order_type TEXT NOT NULL,
 address TEXT, pickup_time TEXT, payment_method TEXT, items_json TEXT NOT NULL,
 total_eur REAL, notes TEXT, status TEXT NOT NULL DEFAULT 'nuevo'
);
