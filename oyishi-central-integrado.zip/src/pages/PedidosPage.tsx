import { useEffect, useState } from 'react';

type Item = { name: string; quantity: number; notes?: string };
type Order = { id: number; customer_name: string; order_type: string; address?: string; pickup_time?: string; payment_method?: string; customer_phone?: string; total_eur: number | null; status: string; items: Item[] };
const states = ['nuevo', 'en_preparacion', 'listo', 'entregado', 'cancelado'];

export function PedidosPage() {
  const [password, setPassword] = useState(sessionStorage.getItem('oyishi-orders-password') || '');
  const [orders, setOrders] = useState<Order[]>([]); const [error, setError] = useState('');
  const auth = () => `Basic ${btoa(`oyishi:${password}`)}`;
  const load = async () => { const r = await fetch('/api/orders', { headers: { Authorization: auth() } }); if (!r.ok) { setError('Contraseña incorrecta.'); return; } sessionStorage.setItem('oyishi-orders-password', password); setError(''); setOrders(await r.json()); };
  useEffect(() => { if (password) void load(); }, []);
  const update = async (id: number, status: string) => { await fetch(`/api/orders/${id}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: auth() }, body: JSON.stringify({ status }) }); await load(); };
  if (!sessionStorage.getItem('oyishi-orders-password')) return <main className="max-w-md mx-auto py-32 px-6"><h1 className="text-3xl font-bold mb-5">Pedidos OYISHI</h1><input className="w-full border p-3 mb-3" type="password" placeholder="Contraseña" value={password} onChange={e => setPassword(e.target.value)} /><button className="w-full bg-black text-white p-3" onClick={load}>Entrar</button>{error && <p className="mt-3 text-red-600">{error}</p>}</main>;
  return <main className="max-w-4xl mx-auto py-16 px-6"><div className="flex justify-between items-center mb-6"><h1 className="text-3xl font-bold">Pedidos</h1><button className="border px-4 py-2" onClick={load}>Actualizar</button></div>{orders.length === 0 ? <p>No hay pedidos todavía.</p> : orders.map(o => <article key={o.id} className="border rounded p-5 mb-4 bg-white"><div className="flex justify-between gap-4"><b>#{o.id} · {o.customer_name}</b><select value={o.status} onChange={e => update(o.id, e.target.value)}>{states.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}</select></div><ul className="my-3 list-disc pl-5">{o.items.map((i, n) => <li key={n}>{i.quantity} × {i.name}{i.notes ? ` — ${i.notes}` : ''}</li>)}</ul><p><b>Total:</b> {o.total_eur === null ? 'Pendiente' : `${o.total_eur} €`}</p><p className="text-sm mt-2">{o.order_type === 'recogida' ? `Recogida: ${o.pickup_time}` : `Domicilio: ${o.address} · ${o.payment_method} · ${o.customer_phone}`}</p></article>)}</main>;
}
