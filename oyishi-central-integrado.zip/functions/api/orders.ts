type Env = { DB: D1Database; OYISHI_TOOL_SECRET: string; DASHBOARD_PASSWORD: string };
const equal = (a: string | null, b: string) => a === b;
const dashboard = (r: Request, e: Env) => equal(r.headers.get('Authorization'), `Basic ${btoa(`oyishi:${e.DASHBOARD_PASSWORD}`)}`);
export const onRequestGet: PagesFunction<Env> = async ({ request, env }) => {
  if (!dashboard(request, env)) return new Response('No autorizado', { status: 401, headers: { 'WWW-Authenticate': 'Basic realm="Pedidos OYISHI"' } });
  const { results } = await env.DB.prepare('SELECT * FROM orders ORDER BY id DESC').all();
  return Response.json(results.map((o: any) => ({ ...o, items: JSON.parse(o.items_json) })));
};
export const onRequestPost: PagesFunction<Env> = async ({ request, env }) => {
  if (!equal(request.headers.get('x-oyishi-secret'), env.OYISHI_TOOL_SECRET)) return Response.json({ error: 'No autorizado' }, { status: 401 });
  const body: any = await request.json(); const a = body.args || body; const callId = body.call?.call_id || a.source_call_id || null;
  if (!a.confirmed || !a.customer_name || !['recogida','domicilio'].includes(a.order_type) || !Array.isArray(a.items) || !a.items.length) return Response.json({ error: 'Pedido incompleto o sin confirmar' }, { status: 400 });
  if (a.order_type === 'recogida' && !a.pickup_time) return Response.json({ error: 'Falta hora de recogida' }, { status: 400 });
  if (a.order_type === 'domicilio' && (!a.customer_phone || !a.address || !a.payment_method)) return Response.json({ error: 'Faltan datos de domicilio' }, { status: 400 });
  if (callId) { const old = await env.DB.prepare('SELECT id FROM orders WHERE source_call_id = ?').bind(callId).first(); if (old) return Response.json({ ok: true, order_id: old.id, duplicate: true }); }
  const result = await env.DB.prepare('INSERT INTO orders (created_at,source_call_id,customer_name,customer_phone,order_type,address,pickup_time,payment_method,items_json,total_eur,notes,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').bind(new Date().toISOString(),callId,a.customer_name,a.customer_phone||null,a.order_type,a.address||null,a.pickup_time||null,a.payment_method||null,JSON.stringify(a.items),a.total_eur??null,a.notes||null,'nuevo').run();
  return Response.json({ ok: true, order_id: result.meta.last_row_id, status: 'nuevo' }, { status: 201 });
};
