type Env = { DB: D1Database; DASHBOARD_PASSWORD: string };
export const onRequestPatch: PagesFunction<Env> = async ({ request, env, params }) => {
  if (request.headers.get('Authorization') !== `Basic ${btoa(`oyishi:${env.DASHBOARD_PASSWORD}`)}`) return new Response('No autorizado', { status: 401 });
  const { status } = await request.json() as { status: string };
  if (!['nuevo','en_preparacion','listo','entregado','cancelado'].includes(status)) return Response.json({ error: 'Estado inválido' }, { status: 400 });
  await env.DB.prepare('UPDATE orders SET status = ? WHERE id = ?').bind(status, Number(params.id)).run(); return Response.json({ ok: true });
};
